/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// leftFront            motor         1               
// rightFront           motor         3               
// leftBack             motor         2               
// rightBack            motor         4               
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "math.h"
using namespace vex;

// A global instance of competition
competition Competition;
//
inertial interialSensor = inertial(PORT10);
motor_group leftDrive = motor_group(leftFront, leftBack);
motor_group rightDrive = motor_group(rightFront, rightBack);
smartdrive driveTrain = smartdrive(leftDrive, rightDrive, interialSensor, 12.57, 10.5, 9.125, distanceUnits::in);
//If this is set to true that means PID is on
bool PID_on = true;
//constants for PID
double kP = .4;
double kI = 0;
double kD = 0;
double turnkP = 0.0;
double turnkI = 0.0;
double turnkD = 0.0;
//Autonomous Settings
int desiredValue = 0;
int desiredTurnValue = 0;

int error; //SensorValue -DesiredValue : Position -> acceleration
int prevError = 0; //Position 20 milliseconds ago
int derative; // error - prevError : Speed
int totalError = 0; //totalError = totalError + error

int turnError; //SensorValue -DesiredValue : Position -> acceleration
int turnPrevError = 0; //Position 20 milliseconds ago
int turnDerative; // error - prevError : Speed
int turnTotalError = 0; //totalError = totalError + error

//function that would transfer the the inches to degrees
void inch_deg_conversion(double len_inch){
  desiredValue = (len_inch/4)*(180/M_PI);
}

//Variables 
bool resetDriveSensors = false;

int PID_Control(){
  while (PID_on){
    if (resetDriveSensors){
      resetDriveSensors = false;
      leftFront.setPosition(0, deg);
      leftBack.setPosition(0, deg);
      rightFront.setPosition(0, deg);
      rightBack.setPosition(0, deg);
    }
    //Get the position of all motors
    int leftFrontMotorPosition = leftFront.position(deg);
    int rightFrontMotorPosition = rightFront.position(deg);
    int leftBackMotorPosition = leftBack.position(deg);
    int rightBackMotorPosition = rightBack.position(deg);
    ////////////////////////////////////////////////////////
    //Lateral movement PID
    ////////////////////////////////////////////////////////
    //Get average of the 4 motors
    int averagePosition = ((leftBackMotorPosition + leftFrontMotorPosition + rightBackMotorPosition + rightFrontMotorPosition)/4);
    
    //Potential
    error = desiredValue - averagePosition;
    
    //Derivative
    derative = error - prevError;

    //INtegral
    totalError += error;

    double lateralMotorPower = error * kP + derative * kD + totalError * kI;
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
//Turn movement PID
/////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////
        //Get average of the 4 motors
  /**  int turnDifference = ((leftBackMotorPosition + leftFrontMotorPosition) - (rightBackMotorPosition + rightFrontMotorPosition));
    
    //Potential
    turnError = turnDifference - desiredTurnValue;
    
    //Derivative
    turnDerative = turnError - prevError;

    //INtegral
    turnTotalError += turnError;

    **/
    //double turnMotorPower = turnError * turnkP + turnDerative * turnkD + turnTotalError * turnkI;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    
    
    leftBack.spin(forward, lateralMotorPower/**+ turnMotorPower**/, voltageUnits::volt);
    leftFront.spin(forward, lateralMotorPower/** + turnMotorPower**/, voltageUnits::volt);
    rightBack.spin(forward, lateralMotorPower/** - turnMotorPower**/, voltageUnits::volt);
    rightFront.spin(forward, lateralMotorPower/** - turnMotorPower**/, voltageUnits::volt);
    //code
    prevError = error;
    turnPrevError = turnError;
    vex::task::sleep(20);
  }
  
  return 1;
}
// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  vex::task PID_OPERATION(PID_Control);
  resetDriveSensors = true;
  inch_deg_conversion(20);
  desiredTurnValue = 0;

  vex::task::sleep(1000);
  

  


  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  PID_on = false;
  // User control code here, inside the loop

  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
    leftDrive.spin(fwd, Controller1.Axis3.value(), pct);
    rightDrive.spin(fwd, Controller1.Axis2.value(), pct);
    
    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
