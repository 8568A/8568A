/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// leftFront            motor         9               
// rightFront           motor         3               
// leftBack             motor         11              
// rightBack            motor         4               
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;
//
inertial interialSensor = inertial(PORT10); 
motor_group leftDrive = motor_group(leftFront, leftBack);
motor_group rightDrive = motor_group(rightFront, rightBack);
smartdrive driveTrain = smartdrive(leftDrive, rightDrive, interialSensor, 12.57, 10.5, 9.125, distanceUnits::in);

//If this is set to true that means PID is on
bool PID_on = true;
//constants for PID
double kP = .015;
double kI = 0;
double kD = .0125;
double turnkP = .064;
double turnkI = 0.0;
double turnkD = 0;//.0002;
//Autonomous Settings
int desiredDistance = 0;
int desiredTurnValue = 0;
int initialVelocity = 0;
int error; //SensorValue -desiredDistance : Position -> acceleration
int prevError = 0; //Position 20 milliseconds ago
int derative; // error - prevError : Speed
int totalError = 0; //totalError = totalError + error
int integral = 0; //same as total error but used only for integral


int turnError; //SensorValue -desiredDistance : Position -> acceleration
int turnPrevError = 0; //Position 20 milliseconds ago
int turnDerative; // error - prevError : Speed
int turnTotalError = 0; //totalError = totalError + error
int turnIntegral = 0; //sames as total error but used only for integral turning
//Variables 
bool turnPIDon = false;
bool resetDriveSensors = false;

//function that would transfer the the inches to degrees
void inch_deg_conversion(double len_inch){
//the first value is the amount of degrees turned of the bigger wheel once small wheel rotates
//the second value is inches/deg
  desiredDistance = len_inch/ //0.05235987755;
  0.02327105669;
}

int PID_Control(){
  while (PID_on){
    //This is used for reseting the sensors when a new command needs to be executed
    if (resetDriveSensors){
      resetDriveSensors = false;
      leftDrive.setPosition(0, deg);
      rightDrive.setPosition(0, deg);
      interialSensor.setHeading(180, deg);
      
    }
   //Get the position of all motors
  //the number being multipled is inches/deg
  //found by doing gearratio/360*pi*wheeldiameter
    double leftDrivePosition = leftDrive.position(deg);
    double rightDrivePosition = leftDrive.position(deg);

    ////////////////////////////////////////////////////////
    //Lateral movement PID
    ////////////////////////////////////////////////////////
    //Get average of the 4 motors
    double averagePosition = ((leftDrivePosition + rightDrivePosition)/2);
    
    //Proportional- find difference in where it during the loop and its destination
    error = desiredDistance - averagePosition;
    
    //Derivative- The derivative predicts what the error will become and if it thinks it will overshoot then it will slowdown the robot
    derative = error - prevError;
    

    
    //This would account for the integral getting to high of a number that would make the bot overshoot, this value is an experimental value

    if (abs(error) < 40){
      //Integral- this accounts for the P undershooting
      integral += error;
  }
  //Adjusting for the problem when error would reach under zero or even into negatives
    if ((error>0 && integral<0)||(error<0 && integral>0)){ 
      integral = 0; 
  }
    double lateralMotorPower = (error * kP) + (derative * kD) + (integral * kI);
/////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////
//Turn movement PID
/////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////
    if(turnPIDon){
  //Get the sensor value of intertial sensor
      double currentHeading = interialSensor.heading(deg);
      //Potential
      turnError = desiredTurnValue - currentHeading;

          //Get average of the 2 motors
      //float turnDifference = (leftDrivePosition-rightDrivePosition);
  //    int turnDifference = ((leftBackMotorPosition + leftFrontMotorPosition) - (rightBackMotorPosition + rightFrontMotorPosition));
      
      //Potential
      //turnError = turnDifference - desiredTurnValue;
      
      //Derivative
      turnDerative = turnError - prevError;

      //Integral
      turnIntegral += turnError;
      
      //Adjusting for the problem when error would reach under zero or even into negatives
      if(turnError <=0){
        turnIntegral = 0;
      }
      //This would account for the integral getting to high of a number that would make the bot overshoot, this value is an experimental value
      if (abs(turnIntegral) > 15){ //check later to make sure you make use of the max or you just disable it
        turnIntegral = 15;
      }
      }
      double turnMotorPower = turnError * turnkP + turnDerative * turnkD + turnIntegral * turnkI;
      
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    
    leftDrive.spin(forward, lateralMotorPower + turnMotorPower, voltageUnits::volt);
    rightDrive.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);  


    //code
    prevError = error;
    turnPrevError = turnError;
    vex::task::sleep(20);
  }
  
  return 1;
}


void vexcodeInitInertial() {
  Brain.Screen.print("Device initialization...");
  Brain.Screen.setCursor(2, 1);
  // calibrate the smartDrivetrain gyro
  wait(200, msec);
  interialSensor.startCalibration(1);
  Brain.Screen.print("Calibrating Inertial for smartDrivetrain");
  // wait for the gyro calibration process to finish
  while (interialSensor.isCalibrating()) {
    wait(25, msec);
  }
  // reset the screen now that the calibration is complete
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  wait(50, msec);
  Brain.Screen.clearScreen();
}
// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  vexcodeInitInertial();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  vex::task PID_OPERATION(PID_Control);
  resetDriveSensors = true;
  //inch_deg_conversion(24);
  turnPIDon = true;
  desiredTurnValue = 90;

  vex::task::sleep(1000);
  


  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  PID_on = false;
  // User control code here, inside the loop

  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
    leftDrive.spin(fwd, Controller1.Axis3.value(), pct);
    rightDrive.spin(fwd, Controller1.Axis2.value(), pct);
    
    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
