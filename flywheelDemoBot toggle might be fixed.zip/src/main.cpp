/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// intake               motor_group   9, 4            
// flywheel             motor_group   5, 7            
// Controller1          controller                    
// leftFront            motor         1               
// leftBack             motor         8               
// rightFront           motor         10              
// rightBack            motor         20              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
//motor group configurations
motor_group leftDrive = motor_group(leftFront, leftBack);
motor_group rightDrive = motor_group(rightFront, rightBack);
// A global instance of competition
competition Competition;
//variables for the intake if in or out
bool intakeIn = false; //press X to intake in
bool intakeOut = false; //press B to intake out

//creation of toggle task intake
void intakeToggle(){

  if (Controller1.ButtonUp.pressing()){ //change this line for different intake in controller
      /**if (intakeIn){
        intakeIn = false;
      }
      else{
        intakeOut = false;
        intakeIn = true;
      }**/
    intakeOut = false;
    intakeIn = !intakeIn;
 //change this line for different intake in controller
    waitUntil(!(Controller1.ButtonUp.pressing()));
    }

  //waitUntil(!(Controller1.ButtonUp.pressing()));
  if (Controller1.ButtonDown.pressing()){ //change this line for different intake out controller
    /**if (intakeOut){
      intakeOut = false;
      }
    else{
      intakeIn = false;
      intakeOut = true;
      }
      **/
    intakeIn = false;
    intakeOut = !intakeOut;
   //change this line for different intake out controller
    waitUntil(!(Controller1.ButtonDown.pressing()));
  //waitUntil(!(Controller1.ButtonDown.pressing()));
    }
  
  if (intakeIn){
    intake.spin(forward, 100, percent);
  }else{
    if (intakeOut){
      intake.stop();
      intake.spin(reverse, 100, percent);
    }
    else {
      intake.stop();
    }
  }

}


//variables for flywheel being on or off
bool flywheelSpinning = false; //press Y to make flywheel spin

//creation of flywheel toggle task
void flywheelToggle(){
  if(Controller1.ButtonA.pressing()){ //change this to change flywheel controls
    flywheelSpinning = !flywheelSpinning;
    /**if(flywheelSpinning){
      flywheelSpinning = false;
    }
    else{
      flywheelSpinning = true;
    }
    **/
    waitUntil(!(Controller1.ButtonA.pressing()));
  }
  //waitUntil(!(Controller1.ButtonA.pressing()));
  
  
 //change this to change flywheel controls
  if(flywheelSpinning){
    flywheel.spin(forward, 100, percent);
  }
  else{
    flywheel.stop();
  }


  
}

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
    intakeToggle();
    vex::task::sleep(20);
    flywheelToggle();
    leftDrive.spin(forward, Controller1.Axis3.value(), pct);
    rightDrive.spin(reverse, Controller1.Axis2.value(), pct);
    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
